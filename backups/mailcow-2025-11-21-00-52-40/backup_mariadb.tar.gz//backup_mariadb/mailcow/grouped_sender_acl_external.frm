TYPE=VIEW
query=select `mailcow`.`sender_acl`.`logged_in_as` AS `username`,ifnull(group_concat(`mailcow`.`sender_acl`.`send_as` separator \' \'),\'\') AS `send_as_acl` from `mailcow`.`sender_acl` where `mailcow`.`sender_acl`.`send_as`  not like \'@%\' and `mailcow`.`sender_acl`.`external` = \'1\' group by `mailcow`.`sender_acl`.`logged_in_as`
md5=09ac3229473e45408823ae1c2b062fae
updatable=0
algorithm=0
definer_user=mailcow
definer_host=%
suid=2
with_check_option=0
timestamp=0001763700568616959
create-version=2
source=SELECT logged_in_as, IFNULL(GROUP_CONCAT(send_as SEPARATOR \' \'), \'\') AS send_as_acl FROM sender_acl\n        WHERE send_as NOT LIKE \'@%\' AND external = \'1\'\n        GROUP BY logged_in_as
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `mailcow`.`sender_acl`.`logged_in_as` AS `username`,ifnull(group_concat(`mailcow`.`sender_acl`.`send_as` separator \' \'),\'\') AS `send_as_acl` from `mailcow`.`sender_acl` where `mailcow`.`sender_acl`.`send_as`  not like \'@%\' and `mailcow`.`sender_acl`.`external` = \'1\' group by `mailcow`.`sender_acl`.`logged_in_as`
mariadb-version=101115
