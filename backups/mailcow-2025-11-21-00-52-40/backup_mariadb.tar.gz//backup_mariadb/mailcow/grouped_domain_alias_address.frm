TYPE=VIEW
query=select `mailcow`.`mailbox`.`username` AS `username`,ifnull(group_concat(`mailcow`.`mailbox`.`local_part`,\'@\',`mailcow`.`alias_domain`.`alias_domain` separator \' \'),\'\') AS `ad_alias` from (`mailcow`.`mailbox` left join `mailcow`.`alias_domain` on(`mailcow`.`alias_domain`.`target_domain` = `mailcow`.`mailbox`.`domain`)) group by `mailcow`.`mailbox`.`username`
md5=51e390a0a6898af27393aa735056ab07
updatable=0
algorithm=0
definer_user=mailcow
definer_host=%
suid=2
with_check_option=0
timestamp=0001763700568625290
create-version=2
source=SELECT username, IFNULL(GROUP_CONCAT(local_part, \'@\', alias_domain SEPARATOR \' \'), \'\') AS ad_alias FROM mailbox\n        LEFT OUTER JOIN alias_domain ON target_domain=domain\n        GROUP BY username
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `mailcow`.`mailbox`.`username` AS `username`,ifnull(group_concat(`mailcow`.`mailbox`.`local_part`,\'@\',`mailcow`.`alias_domain`.`alias_domain` separator \' \'),\'\') AS `ad_alias` from (`mailcow`.`mailbox` left join `mailcow`.`alias_domain` on(`mailcow`.`alias_domain`.`target_domain` = `mailcow`.`mailbox`.`domain`)) group by `mailcow`.`mailbox`.`username`
mariadb-version=101115
