TYPE=VIEW
query=select `mailcow`.`alias`.`goto` AS `username`,ifnull(group_concat(`mailcow`.`alias`.`address` order by `mailcow`.`alias`.`address` ASC separator \' \'),\'\') AS `aliases` from `mailcow`.`alias` where `mailcow`.`alias`.`address` <> `mailcow`.`alias`.`goto` and `mailcow`.`alias`.`active` = \'1\' and `mailcow`.`alias`.`sogo_visible` = \'1\' and `mailcow`.`alias`.`address`  not like \'@%\' group by `mailcow`.`alias`.`goto`
md5=4b205408d51eeda4eab55e769f003d8c
updatable=0
algorithm=0
definer_user=mailcow
definer_host=%
suid=2
with_check_option=0
timestamp=0001762929158125018
create-version=2
source=SELECT goto, IFNULL(GROUP_CONCAT(address ORDER BY address SEPARATOR \' \'), \'\') AS address FROM alias\n        WHERE address!=goto\n        AND active = \'1\'\n        AND sogo_visible = \'1\'\n        AND address NOT LIKE \'@%\'\n        GROUP BY goto
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `mailcow`.`alias`.`goto` AS `username`,ifnull(group_concat(`mailcow`.`alias`.`address` order by `mailcow`.`alias`.`address` ASC separator \' \'),\'\') AS `aliases` from `mailcow`.`alias` where `mailcow`.`alias`.`address` <> `mailcow`.`alias`.`goto` and `mailcow`.`alias`.`active` = \'1\' and `mailcow`.`alias`.`sogo_visible` = \'1\' and `mailcow`.`alias`.`address`  not like \'@%\' group by `mailcow`.`alias`.`goto`
mariadb-version=101115
