TYPE=VIEW
query=select md5(`mailcow`.`sieve_filters`.`script_data`) AS `id`,`mailcow`.`sieve_filters`.`username` AS `username`,`mailcow`.`sieve_filters`.`script_name` AS `script_name`,`mailcow`.`sieve_filters`.`script_data` AS `script_data` from `mailcow`.`sieve_filters` where `mailcow`.`sieve_filters`.`filter_type` = \'prefilter\'
md5=69b330b635a0abdd34692587c8ad2921
updatable=1
algorithm=0
definer_user=mailcow
definer_host=%
suid=2
with_check_option=0
timestamp=0001762929158162414
create-version=2
source=SELECT md5(script_data), username, script_name, script_data FROM sieve_filters\n        WHERE filter_type = \'prefilter\'
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select md5(`mailcow`.`sieve_filters`.`script_data`) AS `id`,`mailcow`.`sieve_filters`.`username` AS `username`,`mailcow`.`sieve_filters`.`script_name` AS `script_name`,`mailcow`.`sieve_filters`.`script_data` AS `script_data` from `mailcow`.`sieve_filters` where `mailcow`.`sieve_filters`.`filter_type` = \'prefilter\'
mariadb-version=101115
